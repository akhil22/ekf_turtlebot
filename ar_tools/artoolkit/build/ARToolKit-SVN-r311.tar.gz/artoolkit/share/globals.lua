--
-- ARToolKit premake script
--
-- Global settings used
-- 

-- globals
globals = {}

-- debug needs to have a suffix
globals['targetsuffix'] = "_debug"

